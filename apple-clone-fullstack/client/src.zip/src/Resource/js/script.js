// import $ from 'jquery'
// $(document).ready(function () {
//     var array =  $(".footer-links-wrapper div h3");
//     $.each(array, function (indexInArray, valueOfElement) {    
//      $(this).on('click', function() {
//        //to change icon
//        $(this).toggleClass('expanded');
//        // check ul is visible and hide/show
//          var ul =$(this).next("ul");
//          if(!ul.is(':visible')){
//              $(this).next("ul").show();
//          }else{
//              $(this).next("ul").hide();
//          }
//        });
//        $(this).hover(
//          function() {
//              $(this).css('background-color', 'lightblue');
//          },
//          function() {
//              $(this).css('background-color', ''); // Restore default background color
//          }
//      );
      
//     });
  
//     $(window).on('resize', function() {
//      if (window.matchMedia('(max-width: 768px)').matches) {
//        // Code to run when viewport width is 600px or less
//      } else {
//          $(".footer-links-wrapper div ul").show();
         
         
//        // Code to run when viewport width is more than 600px
//        console.log('Viewport width is more than 600px');
//      }
//    });
  

//     });
  
  
  
  
  
  
  
  