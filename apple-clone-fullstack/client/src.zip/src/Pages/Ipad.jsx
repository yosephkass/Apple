import React from 'react'

const style = {
  textAlign: 'center'
}
const Ipad = () => {
  return (
    <div>
        <br /><br /><br /><br />
       <h1 style={style}> Ipad</h1></div>
  )
}

export default Ipad