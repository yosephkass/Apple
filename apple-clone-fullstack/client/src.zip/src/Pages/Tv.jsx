import React from 'react'
const style = {
  textAlign: 'center'
}
const Tv = () => {
  return (
    <div>
        <br /><br /><br /><br />
        <h1 style={style}>Tv</h1>
        
        </div>
  )
}

export default Tv