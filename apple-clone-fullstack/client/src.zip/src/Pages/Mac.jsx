import React from 'react'

const style = {
  textAlign: 'center'
}

const Mac = () => {
  return (
    <div> 
      <br /><br /><br /><br />
    <h1 style={style}>MAC</h1>

    </div>
  )
}

export default Mac