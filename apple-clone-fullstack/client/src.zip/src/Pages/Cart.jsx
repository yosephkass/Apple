import React from 'react'
const style = {
  textAlign: 'center'
}

const Cart = () => {
  return (
    <div>
          <br /><br /><br /><br />
        <h1 style={style}>Cart</h1>
    </div>
  )
}

export default Cart