import React from 'react'

const style = {
  textAlign: 'center'
}
const Four04 = () => {
  return (
    <div>

    <div className="container">
        <div className="center">
          <br /><br /><br /><br />
        <h1 style={style}>Four404</h1>
        </div>
    </div>

    </div>
  )
}

export default Four04