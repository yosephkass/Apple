import React from 'react'

const style = {
  textAlign: 'center'
}
const Support = () => {
  return (
    <div>
        <br /><br /><br /><br />
        <h1 style={style}>Support</h1></div>
  )
}

export default Support